Tham so:

number_generation = 500 (so luong the he)
emp = 0.3 (tham so de lai ghep)
dimension_one = 76 (so luong dinh cua task1)
dimension_two = 56 (so luong dinh cua task2) = dimension_one - 20


Giai thich ket qua trong file: Moi muc duoc gan cach boi ------------------------------------------

+	Dau tien là solution task1
+	Soluion task2
+	Ma tran distance
+ 	chi phi cua task 1 (da tinh vong lai tu thanh pho cuoi cung toi thanh pho dau tien)
+	chi phi cua task 2 (da tinh vong lai tu thanh pho cuoi cung toi thanh pho dau tien)
+ 	rank cua task 1 (da tinh vong lai tu thanh pho cuoi cung toi thanh pho dau tien)
+	rank cua task 2 (da tinh vong lai tu thanh pho cuoi cung toi thanh pho dau tien)
+ 	skill factor
+ 	scalar_fitness
